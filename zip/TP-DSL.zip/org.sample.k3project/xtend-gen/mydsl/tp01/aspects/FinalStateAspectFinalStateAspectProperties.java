package mydsl.tp01.aspects;

@SuppressWarnings("all")
public class FinalStateAspectFinalStateAspectProperties {
}
