package mydsl.tp01.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.ut2j.tp01.State;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateAspect {
}
